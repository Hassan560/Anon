import React from "react";

//pages
import SectionTwo from "../Layout/Section/SectionTwo";

const About = () => {
  return (
    <>
      <SectionTwo />
    </>
  );
};

export default About;
