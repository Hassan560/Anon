import React from 'react'
import ContributeSec from '../Layout/Section/ContributeSec'

const Contribute = () => {
  return (
    <><ContributeSec /></>
  )
}

export default Contribute