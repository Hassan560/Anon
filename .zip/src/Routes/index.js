import React from 'react'
import {Route} from 'react-router-dom'

const index = () => {
  return (
    <div>index</div>
  )
}

export default index