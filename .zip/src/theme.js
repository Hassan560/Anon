export const color = {
  blueColor: "#2544B8",
  redColor: "#FC1C26",
};

