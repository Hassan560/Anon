import React from 'react'

const ButCom = (props) => {
    return (
        <button>{props.children}</button>
    )
}

export default ButCom