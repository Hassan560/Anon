import React from 'react'
import Footer from '../Layout/Footer/Footer'

const DMCA = () => {
  return (
    <><Footer /></>
  )
}

export default DMCA