import React from 'react'
import ContactSec from '../Layout/Section/ContactSec'

const Contact = () => {
  return (
    <>
      <ContactSec />
    </>
  )
}

export default Contact